Hey! I hope you enjoy my screensaver! You can find it here:
https://editor.p5js.org/zaneburk9/sketches/96I_KOT0b

Simply load the page, and hit the play button in the top left corner to view the screensaver.

The screensaver is the world, "Hello!" crafted using p5.js' in-program rectangle creating command, along with
it's circle creating command.

It's a little trippy for me to look at - I found myself staring at it and trying to catch a moment
where the "Hello!" was completely parallel with the screen, as if it were typed straight onto the
page. Give it a look, you'll see what I mean!